# Food-Delivery-Website
# NM-APEC-IT-GROUP-7
# FULL STACK DEVELOPMENT WITH JAVA NM 2.0
## PROJECT TITLE - FOOD DELIVERY APPLICATION AND WEBSITE

![FOOD DELIVERY APPLICATION AND WEBSITE]-(https://github.com/Nandhini4/Food-Delivery-Website)

Some screenshots from the project

![Screenshot ](https://github.com/Nandhini4/Food-Delivery-Website/tree/main/PROJECT%20SCREENSHOTS)
